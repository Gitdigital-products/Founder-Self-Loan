Contribution guidelines with governance-first review policy.

# loaner-ledger

## Name
loaner-ledger

## Purpose
Ecosystem subsystem.

## Scope
Owns its internal domain logic and governance. Integrates with other ecosystem systems via documented adapters.

## Governance
Dual-manager approval required for financial state mutations.
All structural changes require governance PR approval.

## Tax-First Notes
State and Federal tax separation encoded in /config/tax/state and /config/tax/federal.

## Integrations
- kyc-validator-and-workflow-engine
- vault-plugins
- loaner-ledger (if financial)

## Automation
CI, governance checks, audit export workflows included.
